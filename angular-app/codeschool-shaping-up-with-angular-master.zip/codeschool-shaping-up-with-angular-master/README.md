codeschool-shaping-up-with-angular
==================================

Source code for the shaping up with angular course run by Codeschool at https://www.codeschool.com/courses/shaping-up-with-angular-js/
